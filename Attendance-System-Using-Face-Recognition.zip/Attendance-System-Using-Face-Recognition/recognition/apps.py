from django.apps import AppConfig


class RecognitionConfig(AppConfig):
    name = 'recognition'
